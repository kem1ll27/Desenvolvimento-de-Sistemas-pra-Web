<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Tarefas - Fase 2 (Banco de Dados)</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');
        
        body {
            font-family: 'Inter', system-ui, sans-serif;
            max-width: 800px;
            margin: 40px auto;
            padding: 20px;
            background: #f8fafc;
            color: #1e2937;
        }
        
        h1 {
            text-align: center;
            color: #0f172a;
            margin-bottom: 10px;
        }
        
        .container {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1);
        }
        
        form {
            display: flex;
            gap: 10px;
            margin-bottom: 30px;
        }
        
        input[type="text"] {
            flex: 1;
            padding: 14px 16px;
            border: 2px solid #e2e8f0;
            border-radius: 8px;
            font-size: 16px;
            transition: all 0.2s;
        }
        
        input[type="text"]:focus {
            outline: none;
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2);
        }
        
        button {
            padding: 14px 24px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        button[name="acao"][value="adicionar"] {
            background: #3b82f6;
            color: white;
        }
        
        button[name="acao"][value="adicionar"]:hover {
            background: #2563eb;
        }
        
        .tarefa {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 16px 20px;
            background: white;
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            margin-bottom: 12px;
            transition: all 0.2s;
        }
        
        .tarefa:hover {
            box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            transform: translateY(-2px);
        }
        
        .tarefa span {
            font-size: 17px;
            flex: 1;
        }
        
        .concluida span {
            text-decoration: line-through;
            color: #64748b;
        }
        
        .acoes {
            display: flex;
            gap: 8px;
        }
        
        .acoes button {
            padding: 8px 16px;
            font-size: 14px;
        }
        
        .btn-concluir {
            background: #22c55e;
            color: white;
        }
        
        .btn-concluir:hover {
            background: #16a34a;
        }
        
        .btn-reabrir {
            background: #eab308;
            color: white;
        }
        
        .btn-deletar {
            background: #ef4444;
            color: white;
        }
        
        .btn-deletar:hover {
            background: #dc2626;
        }
        
        .vazia {
            text-align: center;
            color: #64748b;
            font-style: italic;
            padding: 40px 20px;
        }
    </style>
</head>
<body>
    <h1>Lista de Tarefas <small style="font-size: 0.6em; color: #64748b;">(PDO + MySQL)</small></h1>
    <div class="container">
    <!-- Formulário para adicionar tarefa -->
    <form method="POST">
        <input type="text" name="titulo" placeholder="Nova tarefa" required>
        <button type="submit" name="acao" value="adicionar">Adicionar</button>
    </form>

    <h2 style="margin-bottom: 20px; color: #334155;">Tarefas</h2>
    <?php
    // Configuração do banco
    $host = 'localhost';
    $dbname = 'todo_db';
    $user = 'root';
    $pass = ''; // Ajuste conforme seu ambiente
    
    try {
        $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        die("Erro de conexão: " . $e->getMessage());
    }
    
    // Processar ações
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['acao'])) {
            if ($_POST['acao'] === 'adicionar' && !empty($_POST['titulo'])) {
                $stmt = $pdo->prepare("INSERT INTO tarefas (titulo, status) VALUES (?, 'pendente')");
                $stmt->execute([trim($_POST['titulo'])]);
            } elseif ($_POST['acao'] === 'atualizar' && isset($_POST['id'])) {
                $stmt = $pdo->prepare("UPDATE tarefas SET status = IF(status = 'pendente', 'concluida', 'pendente') WHERE id = ?");
                $stmt->execute([$_POST['id']]);
            } elseif ($_POST['acao'] === 'deletar' && isset($_POST['id'])) {
                $stmt = $pdo->prepare("DELETE FROM tarefas WHERE id = ?");
                $stmt->execute([$_POST['id']]);
            }
        }
    }
    
    // Listar tarefas
    $stmt = $pdo->query("SELECT * FROM tarefas ORDER BY id");
    $tarefas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    ?>
    
    <?php foreach ($tarefas as $tarefa): ?>
        <div class="tarefa <?= $tarefa['status'] === 'concluida' ? 'concluida' : '' ?>">
            <span><?= htmlspecialchars($tarefa['titulo']) ?></span>
            <div class="acoes">
                <form method="POST" style="display: inline;">
                    <input type="hidden" name="id" value="<?= $tarefa['id'] ?>">
                    <button type="submit" name="acao" value="atualizar" class="<?= $tarefa['status'] === 'pendente' ? 'btn-concluir' : 'btn-reabrir' ?>">
                        <?= $tarefa['status'] === 'pendente' ? 'Concluir' : 'Reabrir' ?>
                    </button>
                </form>
                <form method="POST" style="display: inline;">
                    <input type="hidden" name="id" value="<?= $tarefa['id'] ?>">
                    <button type="submit" name="acao" value="deletar" class="btn-deletar" onclick="return confirm('Tem certeza que deseja deletar esta tarefa?')">Deletar</button>
                </form>
            </div>
        </div>
    <?php endforeach; ?>
    
    <?php if (empty($tarefas)): ?>
        <p class="vazia">Nenhuma tarefa cadastrada ainda. Adicione sua primeira tarefa acima! ✨</p>
    <?php endif; ?>
    </div>
</body>
</html>
