# Sistema de Lista de Tarefas em PHP

## Descrição
Aplicação simples de To-Do List com duas fases:
- **Fase 1**: Persistência em arquivo texto (`tarefas.txt`).
- **Fase 2**: Persistência em banco de dados MySQL usando PDO.

## Como Rodar Localmente

### Pré-requisitos
- PHP 7.4+ instalado
- Para Fase 2: MySQL/MariaDB instalado e rodando

### Fase 1 (Arquivo Texto)
1. Coloque os arquivos da pasta `todo-fase1` em um servidor web (ex: XAMPP, WAMP ou PHP built-in).
2. Acesse `http://localhost/todo-fase1/index.php`
3. O arquivo `tarefas.txt` será criado automaticamente se não existir.

### Fase 2 (Banco de Dados)
1. Crie o banco de dados executando o `script.sql` (use phpMyAdmin ou linha de comando):
   ```
   mysql -u root -p < script.sql
   ```
2. Ajuste as credenciais no arquivo `todo-fase2/index.php` (usuário, senha, etc.).
3. Coloque os arquivos da pasta `todo-fase2` no servidor web.
4. Acesse `http://localhost/todo-fase2/index.php`

## Estrutura
- `todo-fase1/`: Versão com arquivo texto.
- `todo-fase2/`: Versão com MySQL + PDO.
- `script.sql`: Script de criação da tabela.

Todas as operações CRUD estão implementadas em ambas as fases com Prepared Statements na Fase 2.
